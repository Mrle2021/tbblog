const config = require("@next-theme/eslint-config");

module.exports = config;
